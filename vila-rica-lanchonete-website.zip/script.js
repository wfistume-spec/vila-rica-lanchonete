const translations = {
  pt:{
    "nav.home":"Início","nav.menu":"Cardápio","nav.story":"Nossa história","nav.gallery":"Galeria","nav.visit":"Visite-nos","nav.order":"Ver cardápio",
    "hero.eyebrow":"DESDE 1992 · ITAJUBÁ, MG","hero.title":"Sabor que<br><em>faz a diferença.</em>","hero.copy":"Lanches marcantes, café da manhã e aquele sabor de Vila Rica que você lembra.","hero.cta":"Explorar o cardápio","hero.visit":"Como chegar","hero.scroll":"ROLE PARA DESCOBRIR",
    "intro.kicker":"UMA LANCHONETE COM HISTÓRIA","intro.title":"Do primeiro café ao último lanche.","intro.copy":"No coração de Itajubá, a Vila Rica reúne café, salgados e hambúrgueres em uma experiência simples, acolhedora e cheia de sabor.","intro.link":"Conheça a Vila Rica →",
    "story.kicker":"UM PONTO QUE FAZ PARTE DA CIDADE","story.title":"Verdadeiro sabor de bairro, servido com personalidade.","story.copy":"Uma casa conhecida em Itajubá, com ambiente descontraído e um cardápio que vai do café da manhã aos lanches especiais.","story.stat1":"desde","story.stat2":"avaliação no delivery","story.stat3":"dias de atendimento",
    "menu.kicker":"ESCOLHA SEU FAVORITO","menu.title":"Feito para dar água na boca.","menu.note":"Preços e disponibilidade podem mudar. Confirme no balcão/delivery antes de publicar comercialmente.",
    "gallery.kicker":"POR DENTRO DA EXPERIÊNCIA","gallery.title":"Comida que fala por si.",
    "cta.eyebrow":"SEU PRÓXIMO LANCHE ESTÁ AQUI","cta.title":"Bateu a fome?","cta.copy":"Venha experimentar a Vila Rica.","cta.button":"Visitar a Vila Rica",
    "visit.kicker":"ENCONTRE A GENTE","visit.title":"Seu lugar para matar a fome.","visit.hours":"Seg–Sáb 07h–23h · Dom 17h–23h","visit.map":"Abrir no mapa","visit.call":"Ligar","footer.tag":"Sabor que faz a diferença."
  },
  en:{
    "nav.home":"Home","nav.menu":"Menu","nav.story":"Our story","nav.gallery":"Gallery","nav.visit":"Visit us","nav.order":"View menu",
    "hero.eyebrow":"SINCE 1992 · ITAJUBÁ, MG","hero.title":"Flavor that<br><em>makes the difference.</em>","hero.copy":"Memorable sandwiches, breakfast and the Vila Rica flavor you keep coming back for.","hero.cta":"Explore the menu","hero.visit":"Get directions","hero.scroll":"SCROLL TO DISCOVER",
    "intro.kicker":"A SNACK BAR WITH HISTORY","intro.title":"From the first coffee to the last bite.","intro.copy":"In the heart of Itajubá, Vila Rica brings together coffee, savory snacks and burgers in a simple, welcoming experience full of flavor.","intro.link":"Discover Vila Rica →",
    "story.kicker":"A PLACE THAT BELONGS TO THE CITY","story.title":"True neighborhood flavor, served with personality.","story.copy":"A beloved Itajubá spot with a relaxed atmosphere and a menu ranging from breakfast to signature sandwiches.","story.stat1":"since","story.stat2":"delivery rating","story.stat3":"days open",
    "menu.kicker":"CHOOSE YOUR FAVORITE","menu.title":"Made to make you hungry.","menu.note":"Prices and availability can change. Confirm at the counter/delivery before commercial publication.",
    "gallery.kicker":"INSIDE THE EXPERIENCE","gallery.title":"Food that speaks for itself.",
    "cta.eyebrow":"YOUR NEXT BITE IS HERE","cta.title":"Feeling hungry?","cta.copy":"Come experience Vila Rica.","cta.button":"Visit Vila Rica",
    "visit.kicker":"FIND US","visit.title":"Your place to satisfy the craving.","visit.hours":"Mon–Sat 7am–11pm · Sun 5pm–11pm","visit.map":"Open map","visit.call":"Call","footer.tag":"Flavor that makes the difference."
  },
  es:{
    "nav.home":"Inicio","nav.menu":"Menú","nav.story":"Nuestra historia","nav.gallery":"Galería","nav.visit":"Visítanos","nav.order":"Ver menú",
    "hero.eyebrow":"DESDE 1992 · ITAJUBÁ, MG","hero.title":"Sabor que<br><em>marca la diferencia.</em>","hero.copy":"Sándwiches memorables, desayunos y ese sabor de Vila Rica al que siempre quieres volver.","hero.cta":"Explorar el menú","hero.visit":"Cómo llegar","hero.scroll":"DESLIZA PARA DESCUBRIR",
    "intro.kicker":"UNA LANCHONETE CON HISTORIA","intro.title":"Del primer café al último bocado.","intro.copy":"En el corazón de Itajubá, Vila Rica reúne café, salados y hamburguesas en una experiencia sencilla, acogedora y llena de sabor.","intro.link":"Conoce Vila Rica →",
    "story.kicker":"UN LUGAR QUE FORMA PARTE DE LA CIUDAD","story.title":"Auténtico sabor de barrio, servido con personalidad.","story.copy":"Un lugar conocido en Itajubá, con ambiente relajado y un menú que va desde el desayuno hasta los sándwiches especiales.","story.stat1":"desde","story.stat2":"valoración delivery","story.stat3":"días abierto",
    "menu.kicker":"ELIGE TU FAVORITO","menu.title":"Hecho para abrir el apetito.","menu.note":"Los precios y la disponibilidad pueden cambiar. Confirma en el local/delivery antes de publicar comercialmente.",
    "gallery.kicker":"DENTRO DE LA EXPERIENCIA","gallery.title":"Comida que habla por sí sola.",
    "cta.eyebrow":"TU PRÓXIMO BOCADO ESTÁ AQUÍ","cta.title":"¿Tienes hambre?","cta.copy":"Ven a vivir la experiencia Vila Rica.","cta.button":"Visitar Vila Rica",
    "visit.kicker":"ENCUÉNTRANOS","visit.title":"Tu lugar para matar el hambre.","visit.hours":"Lun–Sáb 07:00–23:00 · Dom 17:00–23:00","visit.map":"Abrir mapa","visit.call":"Llamar","footer.tag":"Sabor que marca la diferencia."
  }
};

const menu = [
  {cat:"classic",name:"V-Burguer",desc:"Pão tostado na manteiga, hambúrguer artesanal 100g, mussarela em dobro e maionese especial.",price:"R$ 27,90"},
  {cat:"classic",name:"V-Salada",desc:"Pão, hambúrguer 100g, queijo, alface, tomate e cebola roxa.",price:"R$ 28,90"},
  {cat:"classic",name:"V-Bacon",desc:"Pão, hambúrguer 100g, queijo e bacon.",price:"R$ 29,90"},
  {cat:"classic",name:"V-Pickle",desc:"Hambúrguer, queijo, bacon, cebola roxa e picles.",price:"R$ 30,90"},
  {cat:"classic",name:"V-Cheddar",desc:"Hambúrguer 100g, cheddar e bacon crocante.",price:"R$ 31,90"},
  {cat:"special",name:"X-Treme Full Burguer",desc:"Hambúrguer artesanal 200g, ovo, queijo em dobro, presunto, bacon, alface, tomate, cebola caramelizada e maionese especial.",price:"R$ 43,90"},
  {cat:"special",name:"Ultimate Triple Cheese Burguer",desc:"Hambúrguer artesanal 200g, queijo em dobro bem derretido e maionese especial.",price:"R$ 35,90"},
  {cat:"special",name:"Epic Bacon Burguer",desc:"Hambúrguer artesanal 200g, queijo, bacon crocante, cebola roxa caramelizada e maionese especial.",price:"R$ 40,90"},
  {cat:"savory",name:"Esfirra de frango com catupiry",desc:"Salgado assado recheado.",price:"R$ 10,90"},
  {cat:"savory",name:"Esfirra de carne",desc:"Salgado assado recheado com carne.",price:"R$ 10,90"},
  {cat:"savory",name:"Coxinha de frango",desc:"Coxinha tradicional de frango.",price:"R$ 10,90"},
  {cat:"savory",name:"Coxinha de frango c/ catupiry",desc:"Coxinha de frango com catupiry.",price:"R$ 10,90"},
  {cat:"breakfast",name:"Pão na chapa",desc:"Clássico para começar o dia.",price:"R$ 6,90"},
  {cat:"breakfast",name:"Pão com ovo",desc:"Pão preparado com ovo.",price:"R$ 9,90"},
  {cat:"breakfast",name:"Queijo quente",desc:"Sanduíche quente de queijo.",price:"R$ 16,90"},
  {cat:"breakfast",name:"Misto quente",desc:"Sanduíche quente de presunto e queijo.",price:"R$ 16,90"},
  {cat:"sauce",name:"Baconese defumada",desc:"Molho especial com bacon defumado.",price:"R$ 3,00"},
  {cat:"sauce",name:"Jardim de ervas",desc:"Maionese verde especial da casa.",price:"R$ 2,50"},
  {cat:"drinks",name:"Red Bull 250ml",desc:"Energia extra para o dia.",price:"R$ 16,00"},
  {cat:"drinks",name:"Monster 473ml",desc:"Bebida energética.",price:"R$ 14,99"}
];

const categoryLabels = {
  pt:{all:"Todos",classic:"Clássicos",special:"Especiais",savory:"Salgados",breakfast:"Café da manhã",sauce:"Molhos",drinks:"Bebidas"},
  en:{all:"All",classic:"Classics",special:"Specials",savory:"Savory snacks",breakfast:"Breakfast",sauce:"Sauces",drinks:"Drinks"},
  es:{all:"Todos",classic:"Clásicos",special:"Especiales",savory:"Salados",breakfast:"Desayuno",sauce:"Salsas",drinks:"Bebidas"}
};
let lang="pt", active="all";

function applyLanguage(){
  document.querySelectorAll("[data-i18n]").forEach(el=>{
    const key=el.dataset.i18n;
    if(translations[lang][key]) el.innerHTML=translations[lang][key];
  });
  renderTabs(); renderMenu();
  document.documentElement.lang=lang==="pt"?"pt-BR":lang;
}
function renderTabs(){
  const cats=["all","classic","special","savory","breakfast","sauce","drinks"];
  document.getElementById("categoryTabs").innerHTML=cats.map(c=>`<button class="${active===c?'active':''}" onclick="setCategory('${c}')">${categoryLabels[lang][c]}</button>`).join("");
}
function renderMenu(){
  const list=active==="all"?menu:menu.filter(x=>x.cat===active);
  document.getElementById("menuGrid").innerHTML=list.map((x,i)=>`
    <article class="menu-card">
      <span class="number">${String(i+1).padStart(2,"0")}</span>
      <h3>${x.name}</h3><p>${x.desc}</p><div class="price">${x.price}</div>
    </article>`).join("");
}
function setCategory(c){active=c;renderTabs();renderMenu();}
document.getElementById("language").addEventListener("change",e=>{lang=e.target.value;applyLanguage()});
document.getElementById("menuToggle").addEventListener("click",()=>document.querySelector(".nav").classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>document.querySelector(".nav").classList.remove("open")));
window.addEventListener("scroll",()=>document.getElementById("header").classList.toggle("scrolled",scrollY>40));
window.addEventListener("load",()=>setTimeout(()=>document.getElementById("loader").classList.add("done"),500));
document.getElementById("year").textContent=new Date().getFullYear();
applyLanguage();
