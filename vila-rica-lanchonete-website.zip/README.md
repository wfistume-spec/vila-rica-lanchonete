# Vila Rica Lanchonete — Website

A cinematic, responsive restaurant website using the real photos supplied for this project.

## Files
- `index.html` — website structure
- `styles.css` — design and responsive styling
- `script.js` — language switcher, menu filters, mobile navigation
- `assets/` — supplied Vila Rica photos

## Languages
Português (default), English, Español.

## Important
The menu data in `script.js` was populated from publicly available online menu information for the Vila Rica location in Itajubá. Verify current prices/items with the business before publishing.

## GitHub Pages
1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `script.js`, and the entire `assets` folder.
3. Open Settings → Pages.
4. Choose the `main` branch and `/ (root)`.
5. Save. GitHub will give you the live website URL.
